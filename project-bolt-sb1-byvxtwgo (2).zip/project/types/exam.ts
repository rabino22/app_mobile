export interface ExamSession {
  id: string;
  subject: string;
  difficulty: string;
  topics: string[];
  questions: Question[];
  startTime: Date;
  endTime?: Date;
  duration?: number;
  answers: ExamAnswer[];
  score?: number;
  totalPoints?: number;
  status: 'in-progress' | 'completed' | 'abandoned';
}

export interface ExamAnswer {
  questionId: string;
  selectedAnswer: string;
  isCorrect: boolean;
  timeSpent: number;
}

export interface ExamResult {
  id: string;
  subject: string;
  difficulty: string;
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  totalPoints: number;
  earnedPoints: number;
  duration: number;
  date: Date;
  topics: string[];
  detailedResults: {
    questionId: string;
    question: string;
    selectedAnswer: string;
    correctAnswer: string;
    isCorrect: boolean;
    points: number;
    topic: string;
  }[];
}

export interface Question {
  id: string;
  subject: 'Mathematics' | 'Science' | 'English';
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  type: 'multiple-choice' | 'true-false' | 'short-answer';
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  points: number;
}