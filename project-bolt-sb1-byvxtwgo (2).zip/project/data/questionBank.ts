export interface Question {
  id: string;
  subject: 'Mathematics' | 'Science' | 'English';
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  type: 'multiple-choice' | 'true-false' | 'short-answer';
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  points: number;
  timeEstimate: number; // seconds
  tags?: string[];
}

export const questionBank: Question[] = [
  // Mathematics - Algebra
  {
    id: 'math-alg-001',
    subject: 'Mathematics',
    topic: 'Algebra',
    difficulty: 'Easy',
    type: 'multiple-choice',
    question: 'Solve for x: 3x + 7 = 22',
    options: ['3', '5', '7', '9'],
    correctAnswer: '5',
    explanation: 'Subtract 7 from both sides: 3x = 15, then divide by 3: x = 5',
    points: 2,
    timeEstimate: 60,
    tags: ['linear-equations', 'basic-algebra']
  },
  {
    id: 'math-alg-002',
    subject: 'Mathematics',
    topic: 'Algebra',
    difficulty: 'Medium',
    type: 'multiple-choice',
    question: 'What is the slope of the line passing through points (2, 3) and (6, 11)?',
    options: ['1', '2', '3', '4'],
    correctAnswer: '2',
    explanation: 'Slope = (y₂ - y₁)/(x₂ - x₁) = (11 - 3)/(6 - 2) = 8/4 = 2',
    points: 3,
    timeEstimate: 90,
    tags: ['slope', 'coordinate-geometry']
  },
  {
    id: 'math-alg-003',
    subject: 'Mathematics',
    topic: 'Algebra',
    difficulty: 'Hard',
    type: 'multiple-choice',
    question: 'Factor completely: x² - 5x - 24',
    options: ['(x - 8)(x + 3)', '(x - 6)(x + 4)', '(x + 8)(x - 3)', '(x + 6)(x - 4)'],
    correctAnswer: '(x - 8)(x + 3)',
    explanation: 'Find two numbers that multiply to -24 and add to -5: -8 and 3. So x² - 5x - 24 = (x - 8)(x + 3)',
    points: 4,
    timeEstimate: 120,
    tags: ['factoring', 'quadratics']
  },

  // Mathematics - Geometry
  {
    id: 'math-geo-001',
    subject: 'Mathematics',
    topic: 'Geometry',
    difficulty: 'Easy',
    type: 'multiple-choice',
    question: 'What is the area of a triangle with base 8 cm and height 6 cm?',
    options: ['24 cm²', '28 cm²', '32 cm²', '48 cm²'],
    correctAnswer: '24 cm²',
    explanation: 'Area of triangle = ½ × base × height = ½ × 8 × 6 = 24 cm²',
    points: 2,
    timeEstimate: 45,
    tags: ['area', 'triangles']
  },
  {
    id: 'math-geo-002',
    subject: 'Mathematics',
    topic: 'Geometry',
    difficulty: 'Medium',
    type: 'multiple-choice',
    question: 'In a right triangle, if one angle is 30°, what is the measure of the third angle?',
    options: ['30°', '45°', '60°', '90°'],
    correctAnswer: '60°',
    explanation: 'Sum of angles in a triangle = 180°. We have 90° + 30° + x = 180°, so x = 60°',
    points: 3,
    timeEstimate: 60,
    tags: ['angles', 'triangles', 'right-triangles']
  },
  {
    id: 'math-geo-003',
    subject: 'Mathematics',
    topic: 'Geometry',
    difficulty: 'Hard',
    type: 'multiple-choice',
    question: 'What is the volume of a sphere with radius 3 units? (Use π ≈ 3.14)',
    options: ['113.04 cubic units', '84.78 cubic units', '56.52 cubic units', '28.26 cubic units'],
    correctAnswer: '113.04 cubic units',
    explanation: 'Volume of sphere = (4/3)πr³ = (4/3) × 3.14 × 3³ = (4/3) × 3.14 × 27 = 113.04 cubic units',
    points: 4,
    timeEstimate: 150,
    tags: ['volume', 'spheres', '3d-geometry']
  },

  // Mathematics - Calculus
  {
    id: 'math-calc-001',
    subject: 'Mathematics',
    topic: 'Calculus',
    difficulty: 'Medium',
    type: 'multiple-choice',
    question: 'What is the derivative of f(x) = x³ + 2x² - 5x + 1?',
    options: ['3x² + 4x - 5', '3x² + 2x - 5', 'x² + 4x - 5', '3x² + 4x + 5'],
    correctAnswer: '3x² + 4x - 5',
    explanation: 'Using power rule: d/dx(x³) = 3x², d/dx(2x²) = 4x, d/dx(-5x) = -5, d/dx(1) = 0',
    points: 4,
    timeEstimate: 90,
    tags: ['derivatives', 'power-rule']
  },
  {
    id: 'math-calc-002',
    subject: 'Mathematics',
    topic: 'Calculus',
    difficulty: 'Hard',
    type: 'multiple-choice',
    question: 'Evaluate the integral: ∫(2x + 3)dx',
    options: ['x² + 3x + C', '2x² + 3x + C', 'x² + 3x', '2x + 3x + C'],
    correctAnswer: 'x² + 3x + C',
    explanation: '∫(2x + 3)dx = ∫2x dx + ∫3 dx = x² + 3x + C',
    points: 5,
    timeEstimate: 120,
    tags: ['integration', 'antiderivatives']
  },

  // Science - Physics
  {
    id: 'sci-phy-001',
    subject: 'Science',
    topic: 'Physics',
    difficulty: 'Easy',
    type: 'multiple-choice',
    question: 'What is the formula for calculating speed?',
    options: ['Speed = Distance × Time', 'Speed = Distance ÷ Time', 'Speed = Time ÷ Distance', 'Speed = Distance + Time'],
    correctAnswer: 'Speed = Distance ÷ Time',
    explanation: 'Speed is calculated by dividing the distance traveled by the time taken',
    points: 2,
    timeEstimate: 30,
    tags: ['speed', 'motion', 'formulas']
  },
  {
    id: 'sci-phy-002',
    subject: 'Science',
    topic: 'Physics',
    difficulty: 'Medium',
    type: 'multiple-choice',
    question: 'A car accelerates from 0 to 60 m/s in 10 seconds. What is its acceleration?',
    options: ['4 m/s²', '6 m/s²', '8 m/s²', '10 m/s²'],
    correctAnswer: '6 m/s²',
    explanation: 'Acceleration = (final velocity - initial velocity) ÷ time = (60 - 0) ÷ 10 = 6 m/s²',
    points: 3,
    timeEstimate: 75,
    tags: ['acceleration', 'kinematics']
  },
  {
    id: 'sci-phy-003',
    subject: 'Science',
    topic: 'Physics',
    difficulty: 'Hard',
    type: 'multiple-choice',
    question: 'What is the kinetic energy of a 2 kg object moving at 10 m/s?',
    options: ['50 J', '100 J', '200 J', '400 J'],
    correctAnswer: '100 J',
    explanation: 'Kinetic Energy = ½mv² = ½ × 2 × 10² = ½ × 2 × 100 = 100 J',
    points: 4,
    timeEstimate: 100,
    tags: ['kinetic-energy', 'energy']
  },

  // Science - Chemistry
  {
    id: 'sci-chem-001',
    subject: 'Science',
    topic: 'Chemistry',
    difficulty: 'Easy',
    type: 'multiple-choice',
    question: 'What is the atomic number of carbon?',
    options: ['4', '6', '8', '12'],
    correctAnswer: '6',
    explanation: 'Carbon has 6 protons, which determines its atomic number',
    points: 2,
    timeEstimate: 30,
    tags: ['atomic-number', 'elements']
  },
  {
    id: 'sci-chem-002',
    subject: 'Science',
    topic: 'Chemistry',
    difficulty: 'Medium',
    type: 'multiple-choice',
    question: 'Balance the equation: H₂ + O₂ → H₂O',
    options: ['2H₂ + O₂ → 2H₂O', 'H₂ + 2O₂ → H₂O', 'H₂ + O₂ → 2H₂O', '2H₂ + 2O₂ → 2H₂O'],
    correctAnswer: '2H₂ + O₂ → 2H₂O',
    explanation: 'To balance: 2 H₂ molecules + 1 O₂ molecule → 2 H₂O molecules',
    points: 3,
    timeEstimate: 90,
    tags: ['balancing-equations', 'chemical-reactions']
  },
  {
    id: 'sci-chem-003',
    subject: 'Science',
    topic: 'Chemistry',
    difficulty: 'Hard',
    type: 'multiple-choice',
    question: 'What is the molarity of a solution containing 2 moles of NaCl in 0.5 L of solution?',
    options: ['1 M', '2 M', '4 M', '8 M'],
    correctAnswer: '4 M',
    explanation: 'Molarity = moles of solute ÷ liters of solution = 2 mol ÷ 0.5 L = 4 M',
    points: 4,
    timeEstimate: 120,
    tags: ['molarity', 'solutions', 'concentration']
  },

  // Science - Biology
  {
    id: 'sci-bio-001',
    subject: 'Science',
    topic: 'Biology',
    difficulty: 'Easy',
    type: 'multiple-choice',
    question: 'What is the powerhouse of the cell?',
    options: ['Nucleus', 'Mitochondria', 'Ribosome', 'Cytoplasm'],
    correctAnswer: 'Mitochondria',
    explanation: 'Mitochondria produce ATP (energy) for the cell, earning the nickname "powerhouse of the cell"',
    points: 2,
    timeEstimate: 30,
    tags: ['cell-organelles', 'mitochondria']
  },
  {
    id: 'sci-bio-002',
    subject: 'Science',
    topic: 'Biology',
    difficulty: 'Medium',
    type: 'multiple-choice',
    question: 'What is the process by which plants convert sunlight into chemical energy?',
    options: ['Respiration', 'Photosynthesis', 'Transpiration', 'Fermentation'],
    correctAnswer: 'Photosynthesis',
    explanation: 'Photosynthesis converts light energy into chemical energy (glucose) using CO₂ and H₂O',
    points: 3,
    timeEstimate: 60,
    tags: ['photosynthesis', 'plant-biology']
  },
  {
    id: 'sci-bio-003',
    subject: 'Science',
    topic: 'Biology',
    difficulty: 'Hard',
    type: 'multiple-choice',
    question: 'In DNA replication, which enzyme is responsible for joining DNA fragments?',
    options: ['DNA polymerase', 'DNA ligase', 'Helicase', 'Primase'],
    correctAnswer: 'DNA ligase',
    explanation: 'DNA ligase joins Okazaki fragments on the lagging strand during DNA replication',
    points: 4,
    timeEstimate: 100,
    tags: ['dna-replication', 'enzymes']
  },

  // English - Grammar
  {
    id: 'eng-gram-001',
    subject: 'English',
    topic: 'Grammar',
    difficulty: 'Easy',
    type: 'multiple-choice',
    question: 'Which word is a noun in this sentence: "The quick brown fox jumps over the lazy dog"?',
    options: ['quick', 'brown', 'fox', 'jumps'],
    correctAnswer: 'fox',
    explanation: 'A noun is a person, place, thing, or idea. "Fox" is a thing (animal), making it a noun',
    points: 2,
    timeEstimate: 30,
    tags: ['parts-of-speech', 'nouns']
  },
  {
    id: 'eng-gram-002',
    subject: 'English',
    topic: 'Grammar',
    difficulty: 'Medium',
    type: 'multiple-choice',
    question: 'Choose the correct sentence:',
    options: [
      'Neither the students nor the teacher were ready.',
      'Neither the students nor the teacher was ready.',
      'Neither the student nor the teachers was ready.',
      'Neither the student nor the teachers were ready.'
    ],
    correctAnswer: 'Neither the students nor the teacher was ready.',
    explanation: 'With "neither...nor," the verb agrees with the subject closest to it. "Teacher" is singular, so use "was"',
    points: 3,
    timeEstimate: 75,
    tags: ['subject-verb-agreement', 'neither-nor']
  },
  {
    id: 'eng-gram-003',
    subject: 'English',
    topic: 'Grammar',
    difficulty: 'Hard',
    type: 'multiple-choice',
    question: 'Identify the type of clause: "Although it was raining, we went for a walk."',
    options: ['Independent clause', 'Dependent clause', 'Compound clause', 'Both independent and dependent'],
    correctAnswer: 'Both independent and dependent',
    explanation: '"Although it was raining" is dependent (subordinate), "we went for a walk" is independent',
    points: 4,
    timeEstimate: 90,
    tags: ['clauses', 'sentence-structure']
  },

  // English - Literature
  {
    id: 'eng-lit-001',
    subject: 'English',
    topic: 'Literature',
    difficulty: 'Easy',
    type: 'multiple-choice',
    question: 'Who wrote "To Kill a Mockingbird"?',
    options: ['Harper Lee', 'Mark Twain', 'Ernest Hemingway', 'F. Scott Fitzgerald'],
    correctAnswer: 'Harper Lee',
    explanation: 'Harper Lee wrote "To Kill a Mockingbird," published in 1960',
    points: 2,
    timeEstimate: 30,
    tags: ['authors', 'american-literature']
  },
  {
    id: 'eng-lit-002',
    subject: 'English',
    topic: 'Literature',
    difficulty: 'Medium',
    type: 'multiple-choice',
    question: 'What literary device is used in "The wind whispered through the trees"?',
    options: ['Metaphor', 'Simile', 'Personification', 'Alliteration'],
    correctAnswer: 'Personification',
    explanation: 'Personification gives human qualities (whispering) to non-human things (wind)',
    points: 3,
    timeEstimate: 60,
    tags: ['literary-devices', 'personification']
  },
  {
    id: 'eng-lit-003',
    subject: 'English',
    topic: 'Literature',
    difficulty: 'Hard',
    type: 'multiple-choice',
    question: 'In Shakespeare\'s "Hamlet," what is the significance of Yorick\'s skull?',
    options: [
      'It represents the futility of life',
      'It symbolizes death and mortality',
      'It shows Hamlet\'s madness',
      'It represents lost childhood'
    ],
    correctAnswer: 'It symbolizes death and mortality',
    explanation: 'Yorick\'s skull in the graveyard scene symbolizes the inevitability of death and human mortality',
    points: 4,
    timeEstimate: 120,
    tags: ['shakespeare', 'symbolism', 'hamlet']
  },

  // English - Writing
  {
    id: 'eng-writ-001',
    subject: 'English',
    topic: 'Writing',
    difficulty: 'Easy',
    type: 'multiple-choice',
    question: 'What is the first paragraph of an essay called?',
    options: ['Body paragraph', 'Introduction', 'Conclusion', 'Thesis'],
    correctAnswer: 'Introduction',
    explanation: 'The introduction is the opening paragraph that introduces the topic and thesis',
    points: 2,
    timeEstimate: 30,
    tags: ['essay-structure', 'introduction']
  },
  {
    id: 'eng-writ-002',
    subject: 'English',
    topic: 'Writing',
    difficulty: 'Medium',
    type: 'multiple-choice',
    question: 'Which transition word shows contrast?',
    options: ['Furthermore', 'However', 'Therefore', 'Additionally'],
    correctAnswer: 'However',
    explanation: '"However" indicates a contrast or opposition to the previous statement',
    points: 3,
    timeEstimate: 45,
    tags: ['transitions', 'contrast']
  },
  {
    id: 'eng-writ-003',
    subject: 'English',
    topic: 'Writing',
    difficulty: 'Hard',
    type: 'multiple-choice',
    question: 'What is the most effective way to conclude a persuasive essay?',
    options: [
      'Introduce new evidence',
      'Restate the thesis and call for action',
      'Apologize for any weak arguments',
      'Ask rhetorical questions only'
    ],
    correctAnswer: 'Restate the thesis and call for action',
    explanation: 'A strong conclusion restates the main argument and motivates the reader to take action',
    points: 4,
    timeEstimate: 90,
    tags: ['persuasive-writing', 'conclusions']
  }
];

// Utility functions
export const getQuestionsBySubject = (subject: string): Question[] => {
  return questionBank.filter(q => q.subject === subject);
};

export const getQuestionsByTopic = (subject: string, topic: string): Question[] => {
  return questionBank.filter(q => q.subject === subject && q.topic === topic);
};

export const getQuestionsByDifficulty = (difficulty: string): Question[] => {
  return questionBank.filter(q => q.difficulty === difficulty);
};

export const getQuestionsByTags = (tags: string[]): Question[] => {
  return questionBank.filter(q => 
    q.tags && q.tags.some(tag => tags.includes(tag))
  );
};

export const generateExam = (
  subject: string,
  difficulty: string,
  questionCount: number = 10,
  specificTopics?: string[],
  specificTags?: string[]
): Question[] => {
  let availableQuestions = questionBank.filter(q => 
    q.subject === subject && q.difficulty === difficulty
  );

  if (specificTopics && specificTopics.length > 0) {
    availableQuestions = availableQuestions.filter(q => 
      specificTopics.includes(q.topic)
    );
  }

  if (specificTags && specificTags.length > 0) {
    availableQuestions = availableQuestions.filter(q => 
      q.tags && q.tags.some(tag => specificTags.includes(tag))
    );
  }

  // Shuffle and select random questions
  const shuffled = [...availableQuestions].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, Math.min(questionCount, shuffled.length));
};

export const getEstimatedExamTime = (questions: Question[]): number => {
  return questions.reduce((total, question) => total + question.timeEstimate, 0);
};

export const getTopicsBySubject = (subject: string): string[] => {
  const topics = questionBank
    .filter(q => q.subject === subject)
    .map(q => q.topic);
  return [...new Set(topics)];
};

export const getTagsBySubject = (subject: string): string[] => {
  const tags = questionBank
    .filter(q => q.subject === subject)
    .flatMap(q => q.tags || []);
  return [...new Set(tags)];
};