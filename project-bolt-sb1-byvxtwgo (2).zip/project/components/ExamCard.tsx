import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Clock, Target, BookOpen, TrendingUp } from 'lucide-react-native';

interface ExamCardProps {
  subject: string;
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  questionCount: number;
  estimatedTime: number;
  score?: number;
  date?: string;
  onPress: () => void;
  variant?: 'upcoming' | 'completed' | 'featured';
}

export default function ExamCard({
  subject,
  topic,
  difficulty,
  questionCount,
  estimatedTime,
  score,
  date,
  onPress,
  variant = 'upcoming'
}: ExamCardProps) {
  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case 'Easy': return '#10b981';
      case 'Medium': return '#f59e0b';
      case 'Hard': return '#ef4444';
      default: return '#6b7280';
    }
  };

  const getSubjectGradient = (subj: string) => {
    switch (subj) {
      case 'Mathematics': return ['#3b82f6', '#1d4ed8'];
      case 'Science': return ['#10b981', '#047857'];
      case 'English': return ['#8b5cf6', '#6d28d9'];
      default: return ['#6b7280', '#4b5563'];
    }
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    return `${minutes}m`;
  };

  const getSubjectIcon = (subject: string) => {
    switch (subject) {
      case 'Mathematics': return '📐';
      case 'Science': return '🔬';
      case 'English': return '📚';
      default: return '📖';
    }
  };

  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={[styles.card, variant === 'featured' && styles.featuredCard]}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.subjectInfo}>
            <Text style={styles.subjectIcon}>{getSubjectIcon(subject)}</Text>
            <View>
              <Text style={styles.subject}>{subject}</Text>
              <Text style={styles.topic}>{topic}</Text>
            </View>
          </View>
          
          {variant === 'completed' && score !== undefined && (
            <View style={styles.scoreContainer}>
              <Text style={[styles.scoreText, { color: score >= 80 ? '#10b981' : score >= 60 ? '#f59e0b' : '#ef4444' }]}>
                {score}%
              </Text>
            </View>
          )}
        </View>

        {/* Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <BookOpen size={16} color="#6b7280" />
            <Text style={styles.statText}>{questionCount} questions</Text>
          </View>
          
          <View style={styles.statItem}>
            <Clock size={16} color="#6b7280" />
            <Text style={styles.statText}>{formatTime(estimatedTime)}</Text>
          </View>
          
          <View style={[styles.difficultyBadge, { backgroundColor: getDifficultyColor(difficulty) + '20' }]}>
            <Text style={[styles.difficultyText, { color: getDifficultyColor(difficulty) }]}>
              {difficulty}
            </Text>
          </View>
        </View>

        {/* Footer */}
        {date && (
          <View style={styles.footer}>
            <Text style={styles.dateText}>{date}</Text>
            {variant === 'completed' && (
              <View style={styles.completedBadge}>
                <Target size={12} color="#10b981" />
                <Text style={styles.completedText}>Completed</Text>
              </View>
            )}
          </View>
        )}

        {variant === 'featured' && (
          <View style={styles.featuredBadge}>
            <TrendingUp size={12} color="#ffffff" />
            <Text style={styles.featuredText}>Recommended</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 1,
    borderColor: '#f1f5f9',
  },
  featuredCard: {
    borderColor: '#3b82f6',
    borderWidth: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  subjectInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  subjectIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  subject: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 2,
  },
  topic: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
  },
  scoreContainer: {
    alignItems: 'center',
  },
  scoreText: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
  },
  statsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginBottom: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
  },
  difficultyBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 'auto',
  },
  difficultyText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  dateText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9ca3af',
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  completedText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#10b981',
  },
  featuredBadge: {
    position: 'absolute',
    top: -8,
    right: 16,
    backgroundColor: '#3b82f6',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  featuredText: {
    fontSize: 10,
    fontFamily: 'Inter-SemiBold',
    color: '#ffffff',
  },
});