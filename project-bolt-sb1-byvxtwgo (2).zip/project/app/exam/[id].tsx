import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Clock, ChevronLeft, ChevronRight, Flag, CircleCheck as CheckCircle } from 'lucide-react-native';
import { ExamSession, ExamAnswer, Question } from '@/types/exam';
import { generateExam } from '@/data/questionBank';

export default function ExamScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  
  const [examSession, setExamSession] = useState<ExamSession | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [answers, setAnswers] = useState<ExamAnswer[]>([]);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize exam session
  useEffect(() => {
    // In a real app, you'd fetch this from your state management or API
    // For now, we'll create a mock exam session
    const mockExamSession: ExamSession = {
      id: id as string,
      subject: 'Mathematics',
      difficulty: 'Medium',
      topics: ['Algebra', 'Geometry'],
      questions: generateExam('Mathematics', 'Medium', 10),
      startTime: new Date(),
      answers: [],
      status: 'in-progress'
    };
    
    setExamSession(mockExamSession);
    setAnswers(Array(mockExamSession.questions.length).fill(null).map(() => ({
      questionId: '',
      selectedAnswer: '',
      isCorrect: false,
      timeSpent: 0
    })));
  }, [id]);

  // Timer effect
  useEffect(() => {
    if (!examSession) return;

    const timer = setInterval(() => {
      setTimeElapsed(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [examSession]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (answer: string) => {
    setSelectedAnswer(answer);
    
    const newAnswers = [...answers];
    newAnswers[currentQuestionIndex] = {
      questionId: examSession!.questions[currentQuestionIndex].id,
      selectedAnswer: answer,
      isCorrect: answer === examSession!.questions[currentQuestionIndex].correctAnswer,
      timeSpent: timeElapsed
    };
    setAnswers(newAnswers);
  };

  const goToNextQuestion = () => {
    if (currentQuestionIndex < examSession!.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(answers[currentQuestionIndex + 1]?.selectedAnswer || '');
    }
  };

  const goToPreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
      setSelectedAnswer(answers[currentQuestionIndex - 1]?.selectedAnswer || '');
    }
  };

  const handleSubmitExam = () => {
    const unansweredQuestions = answers.filter(answer => !answer.selectedAnswer).length;
    
    if (unansweredQuestions > 0) {
      Alert.alert(
        'Incomplete Exam',
        `You have ${unansweredQuestions} unanswered questions. Are you sure you want to submit?`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Submit', onPress: submitExam }
        ]
      );
    } else {
      submitExam();
    }
  };

  const submitExam = () => {
    setIsSubmitting(true);
    
    // Calculate results
    const correctAnswers = answers.filter(answer => answer.isCorrect).length;
    const totalPoints = examSession!.questions.reduce((sum, q) => sum + q.points, 0);
    const earnedPoints = examSession!.questions.reduce((sum, q, index) => {
      return sum + (answers[index]?.isCorrect ? q.points : 0);
    }, 0);
    
    const score = Math.round((correctAnswers / examSession!.questions.length) * 100);
    
    // Navigate to results screen
    router.push({
      pathname: '/exam/results',
      params: {
        examId: examSession!.id,
        score: score.toString(),
        correctAnswers: correctAnswers.toString(),
        totalQuestions: examSession!.questions.length.toString(),
        earnedPoints: earnedPoints.toString(),
        totalPoints: totalPoints.toString(),
        duration: timeElapsed.toString()
      }
    });
  };

  if (!examSession) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading exam...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const currentQuestion = examSession.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / examSession.questions.length) * 100;
  const answeredQuestions = answers.filter(answer => answer.selectedAnswer).length;

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronLeft size={24} color="#1f2937" />
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <Text style={styles.headerTitle}>{examSession.subject} Exam</Text>
          <Text style={styles.headerSubtitle}>{examSession.difficulty} Level</Text>
        </View>
        <View style={styles.timerContainer}>
          <Clock size={16} color="#6b7280" />
          <Text style={styles.timerText}>{formatTime(timeElapsed)}</Text>
        </View>
      </View>

      {/* Progress Bar */}
      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: `${progress}%` }]} />
        </View>
        <Text style={styles.progressText}>
          {currentQuestionIndex + 1} of {examSession.questions.length}
        </Text>
      </View>

      {/* Question */}
      <ScrollView style={styles.questionContainer} showsVerticalScrollIndicator={false}>
        <View style={styles.questionCard}>
          <View style={styles.questionHeader}>
            <Text style={styles.questionNumber}>Question {currentQuestionIndex + 1}</Text>
            <View style={styles.questionMeta}>
              <Text style={styles.topicTag}>{currentQuestion.topic}</Text>
              <Text style={styles.pointsTag}>{currentQuestion.points} pts</Text>
            </View>
          </View>
          
          <Text style={styles.questionText}>{currentQuestion.question}</Text>
          
          <View style={styles.optionsContainer}>
            {currentQuestion.options?.map((option, index) => (
              <TouchableOpacity
                key={index}
                style={[
                  styles.optionButton,
                  selectedAnswer === option && styles.selectedOption
                ]}
                onPress={() => handleAnswerSelect(option)}
              >
                <View style={styles.optionContent}>
                  <View style={[
                    styles.optionCircle,
                    selectedAnswer === option && styles.selectedCircle
                  ]}>
                    {selectedAnswer === option && (
                      <CheckCircle size={16} color="#ffffff" />
                    )}
                  </View>
                  <Text style={[
                    styles.optionText,
                    selectedAnswer === option && styles.selectedOptionText
                  ]}>
                    {option}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>

      {/* Navigation */}
      <View style={styles.navigation}>
        <TouchableOpacity
          style={[styles.navButton, currentQuestionIndex === 0 && styles.navButtonDisabled]}
          onPress={goToPreviousQuestion}
          disabled={currentQuestionIndex === 0}
        >
          <ChevronLeft size={20} color={currentQuestionIndex === 0 ? "#d1d5db" : "#2563EB"} />
          <Text style={[styles.navButtonText, currentQuestionIndex === 0 && styles.navButtonTextDisabled]}>
            Previous
          </Text>
        </TouchableOpacity>

        <View style={styles.answeredIndicator}>
          <Text style={styles.answeredText}>
            {answeredQuestions}/{examSession.questions.length} answered
          </Text>
        </View>

        {currentQuestionIndex === examSession.questions.length - 1 ? (
          <TouchableOpacity
            style={styles.submitButton}
            onPress={handleSubmitExam}
            disabled={isSubmitting}
          >
            <Flag size={20} color="#ffffff" />
            <Text style={styles.submitButtonText}>
              {isSubmitting ? 'Submitting...' : 'Submit Exam'}
            </Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={styles.navButton}
            onPress={goToNextQuestion}
          >
            <Text style={styles.navButtonText}>Next</Text>
            <ChevronRight size={20} color="#2563EB" />
          </TouchableOpacity>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  backButton: {
    padding: 8,
  },
  headerInfo: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
  },
  headerSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
  },
  timerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#f3f4f6',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  timerText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    gap: 12,
  },
  progressBar: {
    flex: 1,
    height: 6,
    backgroundColor: '#e5e7eb',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#2563EB',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
  },
  questionContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  questionCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    marginVertical: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  questionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  questionNumber: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#2563EB',
  },
  questionMeta: {
    flexDirection: 'row',
    gap: 8,
  },
  topicTag: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
    backgroundColor: '#f3f4f6',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  pointsTag: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#059669',
    backgroundColor: '#dcfce7',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  questionText: {
    fontSize: 18,
    fontFamily: 'Inter-Regular',
    color: '#1f2937',
    lineHeight: 26,
    marginBottom: 24,
  },
  optionsContainer: {
    gap: 12,
  },
  optionButton: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedOption: {
    backgroundColor: '#eff6ff',
    borderColor: '#2563EB',
  },
  optionContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  optionCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#d1d5db',
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedCircle: {
    backgroundColor: '#2563EB',
    borderColor: '#2563EB',
  },
  optionText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1f2937',
    flex: 1,
  },
  selectedOptionText: {
    color: '#2563EB',
    fontFamily: 'Inter-Medium',
  },
  navigation: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  navButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#f3f4f6',
  },
  navButtonDisabled: {
    opacity: 0.5,
  },
  navButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#2563EB',
  },
  navButtonTextDisabled: {
    color: '#d1d5db',
  },
  answeredIndicator: {
    alignItems: 'center',
  },
  answeredText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#2563EB',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
  },
  submitButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#ffffff',
  },
});