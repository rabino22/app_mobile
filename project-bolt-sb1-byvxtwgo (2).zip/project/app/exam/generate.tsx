import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { ChevronLeft, Play, Clock, Target, BookOpen, Zap } from 'lucide-react-native';
import { generateExam } from '@/data/questionBank';

export default function GenerateExamScreen() {
  const router = useRouter();
  
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('');
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);
  const [questionCount, setQuestionCount] = useState(10);

  const subjects = [
    {
      name: 'Mathematics',
      icon: '📐',
      color: '#2563EB',
      topics: ['Algebra', 'Geometry', 'Calculus', 'Statistics', 'Trigonometry']
    },
    {
      name: 'Science',
      icon: '🔬',
      color: '#059669',
      topics: ['Physics', 'Chemistry', 'Biology', 'Earth Science', 'Astronomy']
    },
    {
      name: 'English',
      icon: '📚',
      color: '#7C3AED',
      topics: ['Grammar', 'Literature', 'Writing', 'Reading Comprehension', 'Vocabulary']
    }
  ];

  const difficulties = [
    { name: 'Easy', color: '#059669', description: 'Basic concepts and straightforward questions' },
    { name: 'Medium', color: '#f59e0b', description: 'Moderate difficulty with some complex problems' },
    { name: 'Hard', color: '#dc2626', description: 'Advanced topics and challenging questions' }
  ];

  const questionCounts = [5, 10, 15, 20, 25];

  const handleTopicToggle = (topic: string) => {
    setSelectedTopics(prev => 
      prev.includes(topic) 
        ? prev.filter(t => t !== topic)
        : [...prev, topic]
    );
  };

  const handleGenerateExam = () => {
    if (!selectedSubject || !selectedDifficulty) {
      Alert.alert('Missing Information', 'Please select both subject and difficulty level.');
      return;
    }

    // Generate exam questions
    const examQuestions = generateExam(
      selectedSubject,
      selectedDifficulty,
      questionCount,
      selectedTopics.length > 0 ? selectedTopics : undefined
    );

    if (examQuestions.length === 0) {
      Alert.alert('No Questions Available', 'No questions found for the selected criteria. Please try different options.');
      return;
    }

    if (examQuestions.length < questionCount) {
      Alert.alert(
        'Limited Questions',
        `Only ${examQuestions.length} questions available for your selection. Continue with ${examQuestions.length} questions?`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Continue', onPress: () => startExam(examQuestions) }
        ]
      );
    } else {
      startExam(examQuestions);
    }
  };

  const startExam = (questions: any[]) => {
    // Create unique exam ID
    const examId = `exam_${Date.now()}`;
    
    // Navigate to exam screen
    router.push(`/exam/${examId}`);
  };

  const getEstimatedTime = () => {
    const baseTime = selectedDifficulty === 'Easy' ? 1 : selectedDifficulty === 'Medium' ? 1.5 : 2;
    return Math.round(questionCount * baseTime);
  };

  const selectedSubjectData = subjects.find(s => s.name === selectedSubject);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronLeft size={24} color="#1f2937" />
        </TouchableOpacity>
        <Text style={styles.title}>Generate Exam</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Subject Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Subject</Text>
          <View style={styles.subjectGrid}>
            {subjects.map((subject) => (
              <TouchableOpacity
                key={subject.name}
                style={[
                  styles.subjectCard,
                  selectedSubject === subject.name && styles.selectedSubject
                ]}
                onPress={() => {
                  setSelectedSubject(subject.name);
                  setSelectedTopics([]);
                }}
              >
                <Text style={styles.subjectIcon}>{subject.icon}</Text>
                <Text style={[
                  styles.subjectName,
                  selectedSubject === subject.name && { color: subject.color }
                ]}>
                  {subject.name}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Topic Selection */}
        {selectedSubject && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Topics (Optional)</Text>
            <Text style={styles.sectionSubtitle}>
              Leave empty to include all topics, or select specific ones
            </Text>
            <View style={styles.topicGrid}>
              {selectedSubjectData?.topics.map((topic) => (
                <TouchableOpacity
                  key={topic}
                  style={[
                    styles.topicChip,
                    selectedTopics.includes(topic) && styles.selectedTopic
                  ]}
                  onPress={() => handleTopicToggle(topic)}
                >
                  <Text style={[
                    styles.topicText,
                    selectedTopics.includes(topic) && styles.selectedTopicText
                  ]}>
                    {topic}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* Difficulty Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Difficulty</Text>
          <View style={styles.difficultyGrid}>
            {difficulties.map((difficulty) => (
              <TouchableOpacity
                key={difficulty.name}
                style={[
                  styles.difficultyCard,
                  selectedDifficulty === difficulty.name && styles.selectedDifficulty
                ]}
                onPress={() => setSelectedDifficulty(difficulty.name)}
              >
                <View style={styles.difficultyHeader}>
                  <Text style={[
                    styles.difficultyName,
                    selectedDifficulty === difficulty.name && { color: difficulty.color }
                  ]}>
                    {difficulty.name}
                  </Text>
                  <View style={[
                    styles.difficultyIndicator,
                    { backgroundColor: difficulty.color }
                  ]} />
                </View>
                <Text style={styles.difficultyDescription}>
                  {difficulty.description}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Question Count */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Number of Questions</Text>
          <View style={styles.countGrid}>
            {questionCounts.map((count) => (
              <TouchableOpacity
                key={count}
                style={[
                  styles.countButton,
                  questionCount === count && styles.selectedCount
                ]}
                onPress={() => setQuestionCount(count)}
              >
                <Text style={[
                  styles.countText,
                  questionCount === count && styles.selectedCountText
                ]}>
                  {count}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Exam Preview */}
        {selectedSubject && selectedDifficulty && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Exam Preview</Text>
            <View style={styles.previewCard}>
              <View style={styles.previewRow}>
                <BookOpen size={20} color="#6b7280" />
                <Text style={styles.previewLabel}>Subject:</Text>
                <Text style={styles.previewValue}>{selectedSubject}</Text>
              </View>
              <View style={styles.previewRow}>
                <Target size={20} color="#6b7280" />
                <Text style={styles.previewLabel}>Difficulty:</Text>
                <Text style={styles.previewValue}>{selectedDifficulty}</Text>
              </View>
              <View style={styles.previewRow}>
                <Zap size={20} color="#6b7280" />
                <Text style={styles.previewLabel}>Questions:</Text>
                <Text style={styles.previewValue}>{questionCount}</Text>
              </View>
              <View style={styles.previewRow}>
                <Clock size={20} color="#6b7280" />
                <Text style={styles.previewLabel}>Est. Time:</Text>
                <Text style={styles.previewValue}>{getEstimatedTime()} minutes</Text>
              </View>
              {selectedTopics.length > 0 && (
                <View style={styles.previewTopics}>
                  <Text style={styles.previewLabel}>Topics:</Text>
                  <Text style={styles.previewValue}>
                    {selectedTopics.join(', ')}
                  </Text>
                </View>
              )}
            </View>
          </View>
        )}
      </ScrollView>

      {/* Generate Button */}
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[
            styles.generateButton,
            (!selectedSubject || !selectedDifficulty) && styles.disabledButton
          ]}
          onPress={handleGenerateExam}
          disabled={!selectedSubject || !selectedDifficulty}
        >
          <Play size={20} color="#ffffff" />
          <Text style={styles.generateButtonText}>Start Exam</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  backButton: {
    padding: 8,
  },
  title: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
  },
  placeholder: {
    width: 40,
  },
  section: {
    paddingHorizontal: 20,
    paddingVertical: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
    marginBottom: 16,
  },
  subjectGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  subjectCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  selectedSubject: {
    borderColor: '#2563EB',
    backgroundColor: '#eff6ff',
  },
  subjectIcon: {
    fontSize: 28,
    marginBottom: 8,
  },
  subjectName: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#1f2937',
    textAlign: 'center',
  },
  topicGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  topicChip: {
    backgroundColor: '#ffffff',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  selectedTopic: {
    backgroundColor: '#2563EB',
    borderColor: '#2563EB',
  },
  topicText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
  },
  selectedTopicText: {
    color: '#ffffff',
  },
  difficultyGrid: {
    gap: 12,
  },
  difficultyCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  selectedDifficulty: {
    borderColor: '#2563EB',
    backgroundColor: '#eff6ff',
  },
  difficultyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  difficultyName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
  },
  difficultyIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  difficultyDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
  },
  countGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  countButton: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  selectedCount: {
    borderColor: '#2563EB',
    backgroundColor: '#eff6ff',
  },
  countText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
  },
  selectedCountText: {
    color: '#2563EB',
  },
  previewCard: {
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  previewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  previewLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
    flex: 1,
  },
  previewValue: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
  },
  previewTopics: {
    marginTop: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f3f4f6',
  },
  buttonContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  generateButton: {
    backgroundColor: '#2563EB',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  disabledButton: {
    backgroundColor: '#d1d5db',
  },
  generateButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#ffffff',
  },
});