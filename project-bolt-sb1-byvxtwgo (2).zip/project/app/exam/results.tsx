import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Trophy, Clock, Target, Star, CircleCheck as CheckCircle, Circle as XCircle, ArrowRight } from 'lucide-react-native';

export default function ExamResultsScreen() {
  const params = useLocalSearchParams();
  const router = useRouter();

  const {
    score,
    correctAnswers,
    totalQuestions,
    earnedPoints,
    totalPoints,
    duration
  } = params;

  const scoreNum = parseInt(score as string);
  const correctNum = parseInt(correctAnswers as string);
  const totalNum = parseInt(totalQuestions as string);
  const earnedNum = parseInt(earnedPoints as string);
  const totalPointsNum = parseInt(totalPoints as string);
  const durationNum = parseInt(duration as string);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return '#059669';
    if (score >= 70) return '#f59e0b';
    return '#dc2626';
  };

  const getScoreBadge = (score: number) => {
    if (score >= 90) return 'Excellent!';
    if (score >= 80) return 'Great Job!';
    if (score >= 70) return 'Good Work!';
    if (score >= 60) return 'Keep Practicing!';
    return 'Try Again!';
  };

  const getScoreMessage = (score: number) => {
    if (score >= 90) return 'Outstanding performance! You\'ve mastered this topic.';
    if (score >= 80) return 'Well done! You have a strong understanding of the material.';
    if (score >= 70) return 'Good effort! With a bit more practice, you\'ll excel.';
    if (score >= 60) return 'You\'re on the right track. Keep studying and practicing.';
    return 'Don\'t give up! Review the material and try again.';
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <View style={[styles.scoreCircle, { borderColor: getScoreColor(scoreNum) }]}>
              <Trophy size={32} color={getScoreColor(scoreNum)} />
            </View>
            <Text style={styles.scoreText}>{scoreNum}%</Text>
            <Text style={[styles.scoreBadge, { color: getScoreColor(scoreNum) }]}>
              {getScoreBadge(scoreNum)}
            </Text>
            <Text style={styles.scoreMessage}>
              {getScoreMessage(scoreNum)}
            </Text>
          </View>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsContainer}>
          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <CheckCircle size={24} color="#059669" />
              <Text style={styles.statNumber}>{correctNum}</Text>
              <Text style={styles.statLabel}>Correct</Text>
            </View>
            <View style={styles.statCard}>
              <XCircle size={24} color="#dc2626" />
              <Text style={styles.statNumber}>{totalNum - correctNum}</Text>
              <Text style={styles.statLabel}>Incorrect</Text>
            </View>
          </View>
          
          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <Star size={24} color="#f59e0b" />
              <Text style={styles.statNumber}>{earnedNum}</Text>
              <Text style={styles.statLabel}>Points Earned</Text>
            </View>
            <View style={styles.statCard}>
              <Clock size={24} color="#7C3AED" />
              <Text style={styles.statNumber}>{formatTime(durationNum)}</Text>
              <Text style={styles.statLabel}>Time Taken</Text>
            </View>
          </View>
        </View>

        {/* Performance Breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Performance Breakdown</Text>
          
          <View style={styles.performanceCard}>
            <View style={styles.performanceRow}>
              <Text style={styles.performanceLabel}>Questions Answered</Text>
              <Text style={styles.performanceValue}>{totalNum}/{totalNum}</Text>
            </View>
            <View style={styles.performanceRow}>
              <Text style={styles.performanceLabel}>Accuracy Rate</Text>
              <Text style={[styles.performanceValue, { color: getScoreColor(scoreNum) }]}>
                {scoreNum}%
              </Text>
            </View>
            <View style={styles.performanceRow}>
              <Text style={styles.performanceLabel}>Points Earned</Text>
              <Text style={styles.performanceValue}>{earnedNum}/{totalPointsNum}</Text>
            </View>
            <View style={styles.performanceRow}>
              <Text style={styles.performanceLabel}>Average Time per Question</Text>
              <Text style={styles.performanceValue}>
                {Math.round(durationNum / totalNum)}s
              </Text>
            </View>
          </View>
        </View>

        {/* Progress Visualization */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Score Distribution</Text>
          
          <View style={styles.progressCard}>
            <View style={styles.progressRow}>
              <Text style={styles.progressLabel}>Correct Answers</Text>
              <View style={styles.progressBarContainer}>
                <View style={styles.progressBar}>
                  <View 
                    style={[
                      styles.progressFill,
                      { 
                        width: `${(correctNum / totalNum) * 100}%`,
                        backgroundColor: '#059669'
                      }
                    ]} 
                  />
                </View>
                <Text style={styles.progressText}>{correctNum}/{totalNum}</Text>
              </View>
            </View>
            
            <View style={styles.progressRow}>
              <Text style={styles.progressLabel}>Points Earned</Text>
              <View style={styles.progressBarContainer}>
                <View style={styles.progressBar}>
                  <View 
                    style={[
                      styles.progressFill,
                      { 
                        width: `${(earnedNum / totalPointsNum) * 100}%`,
                        backgroundColor: '#f59e0b'
                      }
                    ]} 
                  />
                </View>
                <Text style={styles.progressText}>{earnedNum}/{totalPointsNum}</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Recommendations */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recommendations</Text>
          
          <View style={styles.recommendationCard}>
            {scoreNum >= 90 ? (
              <>
                <Text style={styles.recommendationText}>
                  🎉 Excellent work! You've demonstrated mastery of this subject.
                </Text>
                <Text style={styles.recommendationText}>
                  • Try harder difficulty levels to challenge yourself further
                </Text>
                <Text style={styles.recommendationText}>
                  • Consider exploring advanced topics in this subject
                </Text>
              </>
            ) : scoreNum >= 70 ? (
              <>
                <Text style={styles.recommendationText}>
                  📚 Good progress! Here are some tips to improve:
                </Text>
                <Text style={styles.recommendationText}>
                  • Review the topics where you missed questions
                </Text>
                <Text style={styles.recommendationText}>
                  • Practice more questions in this difficulty level
                </Text>
              </>
            ) : (
              <>
                <Text style={styles.recommendationText}>
                  💪 Keep practicing! Focus on these areas:
                </Text>
                <Text style={styles.recommendationText}>
                  • Review fundamental concepts in this subject
                </Text>
                <Text style={styles.recommendationText}>
                  • Start with easier difficulty levels
                </Text>
                <Text style={styles.recommendationText}>
                  • Take your time to understand each question
                </Text>
              </>
            )}
          </View>
        </View>
      </ScrollView>

      {/* Action Buttons */}
      <View style={styles.actionContainer}>
        <TouchableOpacity 
          style={styles.secondaryButton}
          onPress={() => router.push('/exams')}
        >
          <Text style={styles.secondaryButtonText}>View All Exams</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.primaryButton}
          onPress={() => router.push('/exams')}
        >
          <Text style={styles.primaryButtonText}>Take Another Exam</Text>
          <ArrowRight size={20} color="#ffffff" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  headerContent: {
    alignItems: 'center',
  },
  scoreCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  scoreText: {
    fontSize: 48,
    fontFamily: 'Inter-Bold',
    color: '#1f2937',
    marginBottom: 8,
  },
  scoreBadge: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 8,
  },
  scoreMessage: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
    textAlign: 'center',
    maxWidth: 280,
  },
  statsContainer: {
    padding: 20,
    gap: 16,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1f2937',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
    marginTop: 4,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 16,
  },
  performanceCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  performanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  performanceLabel: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1f2937',
  },
  performanceValue: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
  },
  progressCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  progressRow: {
    marginBottom: 16,
  },
  progressLabel: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1f2937',
    marginBottom: 8,
  },
  progressBarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  progressBar: {
    flex: 1,
    height: 8,
    backgroundColor: '#e5e7eb',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
    minWidth: 40,
  },
  recommendationCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  recommendationText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1f2937',
    lineHeight: 24,
    marginBottom: 8,
  },
  actionContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    gap: 12,
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: '#f3f4f6',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  secondaryButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
  },
  primaryButton: {
    flex: 1,
    backgroundColor: '#2563EB',
    paddingVertical: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  primaryButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#ffffff',
  },
});