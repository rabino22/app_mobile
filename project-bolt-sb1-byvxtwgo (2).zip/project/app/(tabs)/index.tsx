import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { BookOpen, Clock, TrendingUp, Star, ArrowRight, Zap, Target } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import ExamCard from '@/components/ExamCard';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const router = useRouter();

  const stats = [
    { icon: BookOpen, label: 'Total Exams', value: '42', color: '#3b82f6', bgColor: '#eff6ff' },
    { icon: Clock, label: 'Study Time', value: '18h', color: '#10b981', bgColor: '#f0fdf4' },
    { icon: TrendingUp, label: 'Avg Score', value: '87%', color: '#8b5cf6', bgColor: '#faf5ff' },
    { icon: Star, label: 'Best Score', value: '98%', color: '#f59e0b', bgColor: '#fffbeb' },
  ];

  const featuredExams = [
    {
      subject: 'Mathematics',
      topic: 'Algebra Fundamentals',
      difficulty: 'Medium' as const,
      questionCount: 15,
      estimatedTime: 1200, // 20 minutes
    },
    {
      subject: 'Science',
      topic: 'Physics Basics',
      difficulty: 'Easy' as const,
      questionCount: 10,
      estimatedTime: 600, // 10 minutes
    },
  ];

  const recentExams = [
    { 
      subject: 'Mathematics', 
      topic: 'Calculus',
      difficulty: 'Hard' as const,
      questionCount: 12,
      estimatedTime: 1800,
      score: 92, 
      date: '2 days ago' 
    },
    { 
      subject: 'Science', 
      topic: 'Chemistry',
      difficulty: 'Medium' as const,
      questionCount: 15,
      estimatedTime: 1200,
      score: 85, 
      date: '3 days ago' 
    },
    { 
      subject: 'English', 
      topic: 'Grammar',
      difficulty: 'Easy' as const,
      questionCount: 10,
      estimatedTime: 600,
      score: 88, 
      date: '5 days ago' 
    },
  ];

  const quickActions = [
    {
      title: 'Mathematics',
      subtitle: 'Algebra, Geometry, Calculus',
      icon: '📐',
      color: '#3b82f6',
      bgColor: '#eff6ff',
      borderColor: '#3b82f6',
    },
    {
      title: 'Science',
      subtitle: 'Physics, Chemistry, Biology',
      icon: '🔬',
      color: '#10b981',
      bgColor: '#f0fdf4',
      borderColor: '#10b981',
    },
    {
      title: 'English',
      subtitle: 'Grammar, Literature, Writing',
      icon: '📚',
      color: '#8b5cf6',
      bgColor: '#faf5ff',
      borderColor: '#8b5cf6',
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <View>
              <Text style={styles.welcomeText}>Welcome back!</Text>
              <Text style={styles.subtitle}>Ready to challenge yourself today?</Text>
            </View>
            <View style={styles.profileContainer}>
              <Image 
                source={{ uri: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2' }}
                style={styles.profileImage}
              />
            </View>
          </View>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsContainer}>
          {stats.map((stat, index) => (
            <View key={index} style={[styles.statCard, { backgroundColor: stat.bgColor }]}>
              <View style={[styles.statIconContainer, { backgroundColor: stat.color }]}>
                <stat.icon size={20} color="#ffffff" />
              </View>
              <Text style={styles.statValue}>{stat.value}</Text>
              <Text style={styles.statLabel}>{stat.label}</Text>
            </View>
          ))}
        </View>

        {/* Featured Exams */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recommended for You</Text>
            <TouchableOpacity onPress={() => router.push('/exam/generate')}>
              <Text style={styles.seeAllText}>Create Custom</Text>
            </TouchableOpacity>
          </View>
          
          {featuredExams.map((exam, index) => (
            <ExamCard
              key={index}
              subject={exam.subject}
              topic={exam.topic}
              difficulty={exam.difficulty}
              questionCount={exam.questionCount}
              estimatedTime={exam.estimatedTime}
              onPress={() => router.push('/exam/generate')}
              variant="featured"
            />
          ))}
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Start</Text>
          <View style={styles.actionGrid}>
            {quickActions.map((action, index) => (
              <TouchableOpacity 
                key={index}
                style={[
                  styles.actionCard, 
                  { 
                    backgroundColor: action.bgColor,
                    borderLeftColor: action.borderColor 
                  }
                ]}
                onPress={() => router.push('/subjects')}
              >
                <View style={styles.actionContent}>
                  <Text style={styles.actionIcon}>{action.icon}</Text>
                  <View style={styles.actionTextContainer}>
                    <Text style={[styles.actionTitle, { color: action.color }]}>
                      {action.title}
                    </Text>
                    <Text style={styles.actionSubtitle}>{action.subtitle}</Text>
                  </View>
                  <ArrowRight size={20} color={action.color} />
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Recent Exams */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Activity</Text>
            <TouchableOpacity onPress={() => router.push('/exams')}>
              <Text style={styles.seeAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          
          {recentExams.map((exam, index) => (
            <ExamCard
              key={index}
              subject={exam.subject}
              topic={exam.topic}
              difficulty={exam.difficulty}
              questionCount={exam.questionCount}
              estimatedTime={exam.estimatedTime}
              score={exam.score}
              date={exam.date}
              onPress={() => router.push('/exams')}
              variant="completed"
            />
          ))}
        </View>

        {/* CTA Section */}
        <View style={styles.ctaSection}>
          <View style={styles.ctaCard}>
            <View style={styles.ctaContent}>
              <View style={styles.ctaTextContainer}>
                <Text style={styles.ctaTitle}>Ready for a Challenge?</Text>
                <Text style={styles.ctaSubtitle}>
                  Create a custom exam tailored to your learning goals
                </Text>
              </View>
              <TouchableOpacity 
                style={styles.ctaButton}
                onPress={() => router.push('/exam/generate')}
              >
                <Zap size={20} color="#ffffff" />
                <Text style={styles.ctaButtonText}>Generate Exam</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingHorizontal: 20,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcomeText: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#1f2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
  },
  profileContainer: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  profileImage: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 2,
    borderColor: '#ffffff',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 24,
    gap: 12,
  },
  statCard: {
    flex: 1,
    padding: 16,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  statIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1f2937',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
    textAlign: 'center',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 22,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
  },
  seeAllText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#3b82f6',
  },
  actionGrid: {
    gap: 12,
  },
  actionCard: {
    borderRadius: 16,
    padding: 20,
    borderLeftWidth: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  actionContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionIcon: {
    fontSize: 28,
    marginRight: 16,
  },
  actionTextContainer: {
    flex: 1,
  },
  actionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  actionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
  },
  ctaSection: {
    paddingHorizontal: 20,
    paddingBottom: 32,
  },
  ctaCard: {
    backgroundColor: '#1f2937',
    borderRadius: 20,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 8,
  },
  ctaContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  ctaTextContainer: {
    flex: 1,
    marginRight: 16,
  },
  ctaTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#ffffff',
    marginBottom: 4,
  },
  ctaSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#d1d5db',
  },
  ctaButton: {
    backgroundColor: '#3b82f6',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
  },
  ctaButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#ffffff',
  },
});