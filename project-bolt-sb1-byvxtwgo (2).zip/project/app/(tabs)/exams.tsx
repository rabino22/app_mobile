import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Plus, Filter, Clock, Target, Users, X, Play } from 'lucide-react-native';

export default function ExamsScreen() {
  const router = useRouter();
  const [showCreateModal, setShowCreateModal] = useState(false);

  const examHistory = [
    { id: 1, subject: 'Mathematics', topic: 'Algebra', score: 92, time: '15 min', difficulty: 'Hard', date: '2024-01-15' },
    { id: 2, subject: 'Science', topic: 'Physics', score: 85, time: '20 min', difficulty: 'Medium', date: '2024-01-14' },
    { id: 3, subject: 'English', topic: 'Grammar', score: 88, time: '12 min', difficulty: 'Easy', date: '2024-01-13' },
    { id: 4, subject: 'Mathematics', topic: 'Geometry', score: 78, time: '18 min', difficulty: 'Medium', date: '2024-01-12' },
    { id: 5, subject: 'Science', topic: 'Chemistry', score: 91, time: '22 min', difficulty: 'Hard', date: '2024-01-11' },
  ];

  const handleCreateExam = () => {
    setShowCreateModal(false);
    router.push('/exam/generate');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Exams</Text>
        <View style={styles.headerButtons}>
          <TouchableOpacity style={styles.filterButton}>
            <Filter size={20} color="#6b7280" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.createButton}
            onPress={() => setShowCreateModal(true)}
          >
            <Plus size={20} color="#ffffff" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Stats Overview */}
        <View style={styles.statsSection}>
          <View style={styles.statCard}>
            <Clock size={24} color="#2563EB" />
            <Text style={styles.statNumber}>127</Text>
            <Text style={styles.statLabel}>Total Minutes</Text>
          </View>
          <View style={styles.statCard}>
            <Target size={24} color="#059669" />
            <Text style={styles.statNumber}>87%</Text>
            <Text style={styles.statLabel}>Avg Score</Text>
          </View>
          <View style={styles.statCard}>
            <Users size={24} color="#7C3AED" />
            <Text style={styles.statNumber}>24</Text>
            <Text style={styles.statLabel}>Completed</Text>
          </View>
        </View>

        {/* Exam History */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Exams</Text>
          {examHistory.map((exam) => (
            <TouchableOpacity key={exam.id} style={styles.examCard}>
              <View style={styles.examHeader}>
                <View style={styles.examInfo}>
                  <Text style={styles.examSubject}>{exam.subject}</Text>
                  <Text style={styles.examTopic}>{exam.topic}</Text>
                </View>
                <View style={styles.examScore}>
                  <Text style={[styles.scoreText, { color: exam.score >= 90 ? '#059669' : exam.score >= 70 ? '#f59e0b' : '#dc2626' }]}>
                    {exam.score}%
                  </Text>
                </View>
              </View>
              <View style={styles.examMeta}>
                <View style={styles.metaItem}>
                  <Clock size={14} color="#6b7280" />
                  <Text style={styles.metaText}>{exam.time}</Text>
                </View>
                <View style={[styles.difficultyBadge, 
                  exam.difficulty === 'Easy' && styles.easyBadge,
                  exam.difficulty === 'Medium' && styles.mediumBadge,
                  exam.difficulty === 'Hard' && styles.hardBadge
                ]}>
                  <Text style={[styles.difficultyText, 
                    exam.difficulty === 'Easy' && styles.easyText,
                    exam.difficulty === 'Medium' && styles.mediumText,
                    exam.difficulty === 'Hard' && styles.hardText
                  ]}>{exam.difficulty}</Text>
                </View>
                <Text style={styles.examDate}>{exam.date}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Create Exam Modal */}
      <Modal
        visible={showCreateModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowCreateModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Create New Exam</Text>
              <TouchableOpacity onPress={() => setShowCreateModal(false)}>
                <X size={24} color="#6b7280" />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              <Text style={styles.modalDescription}>
                Generate a custom exam with questions tailored to your learning needs. 
                Choose your subject, difficulty level, and topics to create the perfect practice session.
              </Text>

              <View style={styles.quickOptions}>
                <TouchableOpacity style={styles.quickOption} onPress={handleCreateExam}>
                  <Text style={styles.quickOptionIcon}>📐</Text>
                  <Text style={styles.quickOptionTitle}>Mathematics</Text>
                  <Text style={styles.quickOptionSubtitle}>Algebra, Geometry, Calculus</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.quickOption} onPress={handleCreateExam}>
                  <Text style={styles.quickOptionIcon}>🔬</Text>
                  <Text style={styles.quickOptionTitle}>Science</Text>
                  <Text style={styles.quickOptionSubtitle}>Physics, Chemistry, Biology</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.quickOption} onPress={handleCreateExam}>
                  <Text style={styles.quickOptionIcon}>📚</Text>
                  <Text style={styles.quickOptionTitle}>English</Text>
                  <Text style={styles.quickOptionSubtitle}>Grammar, Literature, Writing</Text>
                </TouchableOpacity>
              </View>

              <TouchableOpacity style={styles.customExamButton} onPress={handleCreateExam}>
                <Play size={20} color="#ffffff" />
                <Text style={styles.customExamButtonText}>Generate Custom Exam</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1f2937',
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  filterButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#f3f4f6',
  },
  createButton: {
    backgroundColor: '#2563EB',
    padding: 8,
    borderRadius: 8,
  },
  statsSection: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1f2937',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
    marginTop: 4,
  },
  section: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 16,
  },
  examCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  examHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  examInfo: {
    flex: 1,
  },
  examSubject: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 4,
  },
  examTopic: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
  },
  examScore: {
    alignItems: 'flex-end',
  },
  scoreText: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
  },
  examMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
  },
  difficultyBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  easyBadge: {
    backgroundColor: '#dcfce7',
  },
  mediumBadge: {
    backgroundColor: '#fef3c7',
  },
  hardBadge: {
    backgroundColor: '#fee2e2',
  },
  difficultyText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
  },
  easyText: {
    color: '#166534',
  },
  mediumText: {
    color: '#92400e',
  },
  hardText: {
    color: '#991b1b',
  },
  examDate: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
    marginLeft: 'auto',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingBottom: 20,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  modalTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
  },
  modalBody: {
    padding: 20,
  },
  modalDescription: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
    lineHeight: 24,
    marginBottom: 24,
  },
  quickOptions: {
    gap: 12,
    marginBottom: 24,
  },
  quickOption: {
    backgroundColor: '#f8fafc',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  quickOptionIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  quickOptionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 4,
  },
  quickOptionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
  },
  customExamButton: {
    backgroundColor: '#2563EB',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  customExamButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#ffffff',
  },
});