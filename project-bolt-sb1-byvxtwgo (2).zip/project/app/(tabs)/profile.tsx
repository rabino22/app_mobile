import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { User, Settings, Trophy, Clock, Target, BookOpen, TrendingUp, Award, Star } from 'lucide-react-native';

export default function ProfileScreen() {
  const [activeTab, setActiveTab] = useState('overview');

  const userStats = {
    totalExams: 42,
    totalTime: 18.5, // hours
    avgScore: 87,
    bestScore: 98,
    streak: 12, // days
    totalPoints: 1250,
    rank: 'Advanced',
    achievements: 15
  };

  const subjectStats = [
    { subject: 'Mathematics', exams: 18, avgScore: 89, bestScore: 98, color: '#2563EB' },
    { subject: 'Science', exams: 15, avgScore: 85, bestScore: 95, color: '#059669' },
    { subject: 'English', exams: 9, avgScore: 87, bestScore: 94, color: '#7C3AED' }
  ];

  const recentAchievements = [
    { id: 1, name: 'Perfect Score', description: 'Score 100% on an exam', icon: '🎯', date: '2 days ago' },
    { id: 2, name: 'Speed Demon', description: 'Complete exam in under 10 minutes', icon: '⚡', date: '1 week ago' },
    { id: 3, name: 'Mathematics Master', description: 'Complete 10 math exams', icon: '📐', date: '2 weeks ago' },
    { id: 4, name: 'Consistent Learner', description: '7-day study streak', icon: '🔥', date: '1 month ago' }
  ];

  const weeklyProgress = [
    { day: 'Mon', exams: 2, score: 85 },
    { day: 'Tue', exams: 1, score: 92 },
    { day: 'Wed', exams: 3, score: 78 },
    { day: 'Thu', exams: 2, score: 88 },
    { day: 'Fri', exams: 1, score: 95 },
    { day: 'Sat', exams: 0, score: 0 },
    { day: 'Sun', exams: 1, score: 87 }
  ];

  const getRankColor = (rank: string) => {
    switch (rank) {
      case 'Beginner': return '#6b7280';
      case 'Intermediate': return '#f59e0b';
      case 'Advanced': return '#2563EB';
      case 'Expert': return '#7C3AED';
      case 'Master': return '#059669';
      default: return '#6b7280';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <View style={styles.header}>
          <View style={styles.profileSection}>
            <View style={styles.avatarContainer}>
              <User size={40} color="#ffffff" />
            </View>
            <View style={styles.profileInfo}>
              <Text style={styles.userName}>John Doe</Text>
              <View style={styles.rankContainer}>
                <Award size={16} color={getRankColor(userStats.rank)} />
                <Text style={[styles.rankText, { color: getRankColor(userStats.rank) }]}>
                  {userStats.rank} Level
                </Text>
              </View>
            </View>
          </View>
          <TouchableOpacity style={styles.settingsButton}>
            <Settings size={24} color="#6b7280" />
          </TouchableOpacity>
        </View>

        {/* Stats Overview */}
        <View style={styles.statsContainer}>
          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <BookOpen size={24} color="#2563EB" />
              <Text style={styles.statNumber}>{userStats.totalExams}</Text>
              <Text style={styles.statLabel}>Total Exams</Text>
            </View>
            <View style={styles.statCard}>
              <Clock size={24} color="#059669" />
              <Text style={styles.statNumber}>{userStats.totalTime}h</Text>
              <Text style={styles.statLabel}>Study Time</Text>
            </View>
          </View>
          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <Target size={24} color="#7C3AED" />
              <Text style={styles.statNumber}>{userStats.avgScore}%</Text>
              <Text style={styles.statLabel}>Avg Score</Text>
            </View>
            <View style={styles.statCard}>
              <Trophy size={24} color="#f59e0b" />
              <Text style={styles.statNumber}>{userStats.bestScore}%</Text>
              <Text style={styles.statLabel}>Best Score</Text>
            </View>
          </View>
        </View>

        {/* Tab Navigation */}
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'overview' && styles.activeTab]}
            onPress={() => setActiveTab('overview')}
          >
            <Text style={[styles.tabText, activeTab === 'overview' && styles.activeTabText]}>
              Overview
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'subjects' && styles.activeTab]}
            onPress={() => setActiveTab('subjects')}
          >
            <Text style={[styles.tabText, activeTab === 'subjects' && styles.activeTabText]}>
              Subjects
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'achievements' && styles.activeTab]}
            onPress={() => setActiveTab('achievements')}
          >
            <Text style={[styles.tabText, activeTab === 'achievements' && styles.activeTabText]}>
              Achievements
            </Text>
          </TouchableOpacity>
        </View>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <View style={styles.tabContent}>
            {/* Quick Stats */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Quick Stats</Text>
              <View style={styles.quickStatsContainer}>
                <View style={styles.quickStatItem}>
                  <Text style={styles.quickStatNumber}>{userStats.streak}</Text>
                  <Text style={styles.quickStatLabel}>Day Streak</Text>
                  <Text style={styles.quickStatIcon}>🔥</Text>
                </View>
                <View style={styles.quickStatItem}>
                  <Text style={styles.quickStatNumber}>{userStats.totalPoints}</Text>
                  <Text style={styles.quickStatLabel}>Total Points</Text>
                  <Text style={styles.quickStatIcon}>⭐</Text>
                </View>
                <View style={styles.quickStatItem}>
                  <Text style={styles.quickStatNumber}>{userStats.achievements}</Text>
                  <Text style={styles.quickStatLabel}>Achievements</Text>
                  <Text style={styles.quickStatIcon}>🏆</Text>
                </View>
              </View>
            </View>

            {/* Weekly Progress */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>This Week</Text>
              <View style={styles.weeklyContainer}>
                {weeklyProgress.map((day, index) => (
                  <View key={index} style={styles.weeklyItem}>
                    <Text style={styles.weeklyDay}>{day.day}</Text>
                    <View style={styles.weeklyBar}>
                      <View 
                        style={[
                          styles.weeklyBarFill,
                          { height: `${day.exams * 33}%` }
                        ]} 
                      />
                    </View>
                    <Text style={styles.weeklyCount}>{day.exams}</Text>
                  </View>
                ))}
              </View>
            </View>
          </View>
        )}

        {activeTab === 'subjects' && (
          <View style={styles.tabContent}>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Subject Performance</Text>
              {subjectStats.map((subject, index) => (
                <View key={index} style={styles.subjectCard}>
                  <View style={styles.subjectHeader}>
                    <View style={styles.subjectInfo}>
                      <View style={[styles.subjectDot, { backgroundColor: subject.color }]} />
                      <Text style={styles.subjectName}>{subject.subject}</Text>
                    </View>
                    <Text style={styles.subjectScore}>{subject.avgScore}%</Text>
                  </View>
                  <View style={styles.subjectStats}>
                    <Text style={styles.subjectStatText}>
                      {subject.exams} exams • Best: {subject.bestScore}%
                    </Text>
                  </View>
                  <View style={styles.subjectProgress}>
                    <View style={styles.subjectProgressBar}>
                      <View 
                        style={[
                          styles.subjectProgressFill,
                          { 
                            width: `${subject.avgScore}%`,
                            backgroundColor: subject.color 
                          }
                        ]} 
                      />
                    </View>
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        {activeTab === 'achievements' && (
          <View style={styles.tabContent}>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Recent Achievements</Text>
              {recentAchievements.map((achievement) => (
                <View key={achievement.id} style={styles.achievementCard}>
                  <Text style={styles.achievementIcon}>{achievement.icon}</Text>
                  <View style={styles.achievementInfo}>
                    <Text style={styles.achievementName}>{achievement.name}</Text>
                    <Text style={styles.achievementDescription}>{achievement.description}</Text>
                    <Text style={styles.achievementDate}>{achievement.date}</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 20,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#2563EB',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 4,
  },
  rankContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rankText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
  settingsButton: {
    padding: 8,
  },
  statsContainer: {
    padding: 20,
    gap: 16,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1f2937',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
    marginTop: 4,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    marginHorizontal: 20,
    borderRadius: 12,
    padding: 4,
    marginBottom: 20,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: '#2563EB',
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
  },
  activeTabText: {
    color: '#ffffff',
  },
  tabContent: {
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 16,
  },
  quickStatsContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  quickStatItem: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  quickStatNumber: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1f2937',
  },
  quickStatLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
    marginTop: 4,
  },
  quickStatIcon: {
    fontSize: 20,
    marginTop: 8,
  },
  weeklyContainer: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 12,
    justifyContent: 'space-between',
  },
  weeklyItem: {
    alignItems: 'center',
    flex: 1,
  },
  weeklyDay: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
    marginBottom: 8,
  },
  weeklyBar: {
    width: 20,
    height: 60,
    backgroundColor: '#f3f4f6',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'flex-end',
    overflow: 'hidden',
  },
  weeklyBarFill: {
    width: '100%',
    backgroundColor: '#2563EB',
    borderRadius: 10,
    minHeight: 2,
  },
  weeklyCount: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginTop: 8,
  },
  subjectCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  subjectHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  subjectInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  subjectDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  subjectName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
  },
  subjectScore: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#2563EB',
  },
  subjectStats: {
    marginBottom: 12,
  },
  subjectStatText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
  },
  subjectProgress: {
    marginTop: 8,
  },
  subjectProgressBar: {
    height: 6,
    backgroundColor: '#f3f4f6',
    borderRadius: 3,
    overflow: 'hidden',
  },
  subjectProgressFill: {
    height: '100%',
    borderRadius: 3,
  },
  achievementCard: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  achievementIcon: {
    fontSize: 32,
    marginRight: 16,
  },
  achievementInfo: {
    flex: 1,
  },
  achievementName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 4,
  },
  achievementDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
    marginBottom: 4,
  },
  achievementDate: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6b7280',
  },
});