import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import SubjectCard from '@/components/SubjectCard';
import { getTopicsBySubject } from '@/data/questionBank';

export default function SubjectsScreen() {
  const router = useRouter();
  const [expandedSubject, setExpandedSubject] = useState<string | null>(null);

  const subjects = [
    {
      id: 1,
      name: 'Mathematics',
      icon: '📐',
      color: '#3b82f6',
      totalQuestions: 120,
      completedExams: 18,
      avgScore: 89,
      topics: getTopicsBySubject('Mathematics'),
    },
    {
      id: 2,
      name: 'Science',
      icon: '🔬',
      color: '#10b981',
      totalQuestions: 95,
      completedExams: 12,
      avgScore: 82,
      topics: getTopicsBySubject('Science'),
    },
    {
      id: 3,
      name: 'English',
      icon: '📚',
      color: '#8b5cf6',
      totalQuestions: 85,
      completedExams: 15,
      avgScore: 90,
      topics: getTopicsBySubject('English'),
    },
  ];

  const handleSubjectPress = (subjectName: string) => {
    if (expandedSubject === subjectName) {
      setExpandedSubject(null);
    } else {
      setExpandedSubject(subjectName);
    }
  };

  const handleStartExam = (subject: string) => {
    router.push({
      pathname: '/exam/generate',
      params: { preselectedSubject: subject }
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Subjects</Text>
        <Text style={styles.subtitle}>Choose your area of study</Text>
      </View>

      <ScrollView 
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {subjects.map((subject) => (
          <SubjectCard
            key={subject.id}
            subject={subject.name}
            icon={subject.icon}
            color={subject.color}
            totalQuestions={subject.totalQuestions}
            completedExams={subject.completedExams}
            avgScore={subject.avgScore}
            topics={subject.topics}
            onPress={() => handleSubjectPress(subject.name)}
            isExpanded={expandedSubject === subject.name}
          />
        ))}

        {/* Quick Actions */}
        <View style={styles.quickActionsSection}>
          <Text style={styles.quickActionsTitle}>Quick Actions</Text>
          
          <TouchableOpacity 
            style={styles.quickActionCard}
            onPress={() => router.push('/exam/generate')}
          >
            <View style={styles.quickActionContent}>
              <View style={styles.quickActionIcon}>
                <Text style={styles.quickActionEmoji}>⚡</Text>
              </View>
              <View style={styles.quickActionText}>
                <Text style={styles.quickActionTitle}>Generate Custom Exam</Text>
                <Text style={styles.quickActionSubtitle}>
                  Create a personalized exam with your preferred settings
                </Text>
              </View>
            </View>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.quickActionCard}
            onPress={() => router.push('/exams')}
          >
            <View style={styles.quickActionContent}>
              <View style={styles.quickActionIcon}>
                <Text style={styles.quickActionEmoji}>📊</Text>
              </View>
              <View style={styles.quickActionText}>
                <Text style={styles.quickActionTitle}>View Exam History</Text>
                <Text style={styles.quickActionSubtitle}>
                  Review your past performance and track progress
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingHorizontal: 20,
    paddingVertical: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#1f2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  quickActionsSection: {
    marginTop: 32,
  },
  quickActionsTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 16,
  },
  quickActionCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#f1f5f9',
  },
  quickActionContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f8fafc',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  quickActionEmoji: {
    fontSize: 24,
  },
  quickActionText: {
    flex: 1,
  },
  quickActionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1f2937',
    marginBottom: 4,
  },
  quickActionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6b7280',
    lineHeight: 20,
  },
});